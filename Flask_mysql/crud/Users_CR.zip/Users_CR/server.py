from flask import Flask, render_template, redirect, session, request
app = Flask(__name__)
from users import User

@app.route('/user')
def users():
    users = User.get_all()
    return render_template('user.html', users=users)

@app.route('/new')
def new():
    return render_template('new.html')

@app.route('/add', methods=['POST'])
def add_user():
    User.add_one(request.form)
    return redirect('/user')

if (__name__) == '__main__':
    app.run(debug=True)