class BankAccount:

    all_accounts = []
    # don't forget to add some default values for these parameters!
    def __init__(self, int_rate = 0.01, balance = 0): 
        # your code here! (remember, instance attributes go here)
        # don't worry about user info here; we'll involve the User class soon
        self.int_rate = int_rate
        self.balance = balance
        BankAccount.all_accounts.append(self)
    def deposit(self, amount):
        # your code here
        self.balance += amount
        return self
    def withdraw(self, amount):
        # your code here
        if self.balance >= amount:
            self.balance -= amount
        else:
            print("Insufficient funds: Charging a $5 fee")
            self.balance -= 5
        return self
    def display_account_info(self):
        # your code here
        print(f'Balance: {self.balance}')
        return self
    def yield_interest(self):
        # your code here
        self.balance = self.balance * (self.int_rate + 1)
        return self
    @classmethod
    def all_instances(cls):
        for account in cls.all_accounts:
            print(account)


account1 = BankAccount()
account2 = BankAccount()

account1.deposit(10).deposit(10).deposit(10).withdraw(20).yield_interest().display_account_info()
account2.deposit(20).deposit(15).withdraw(5).withdraw(5).yield_interest().display_account_info()

BankAccount.all_instances()