print("Hello World")

name = "Karl Baldwin"
print("Hello", name)
print("Hello " + name)

number = 6
print("Hello", number)
print("Hello " + str(number))

food1 = "spaghetti"
food2 = "cookies"

print("I love to eat {} and {}.".format(food1, food2))
print(f"I love to eat {food1} and {food2}.")

print(food1.upper())
print(food2.title())